-- Kommandos för att spawna/ta bort bilar. 

RegisterCommand("car", function(source, args)
    local vehicle = args[1] or "tailgater"
    SpawnVehicle(vehicle)
end, false)

RegisterCommand("dv", function(source)
    DeleteVehicle()
end, false)