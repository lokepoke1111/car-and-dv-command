fx_version "bodacious"
game "gta5"

author "lokepoke1111"
description "/car and /dv command."

client_script {
    "client/client.lua",
    "functions/functions.lua"
}