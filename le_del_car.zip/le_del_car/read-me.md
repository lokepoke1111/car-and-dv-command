Thanks for downloading the script!

This is a very simple scripts that allows any player to use /car and /dv commands.

----------------------------------------------------------------------------------

CREDITS:

discord: lokepoke1111

----------------------------------------------------------------------------------

I'm currently just learning to develop, this script is just something simple.

