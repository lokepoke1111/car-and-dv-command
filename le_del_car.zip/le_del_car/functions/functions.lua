function SpawnVehicle(vehicle)
    local vehicleName = vehicle or "tailgater" -- Tailgater är bilen som spawnas om ni bara gör /car.
    if not IsModelInCdimage(vehicleName) or not IsModelAVehicle(vehicleName) then
        notify("Bilen hittas inte.") 
        return 
    end
    RequestModel(vehicleName)
    while not HasModelLoaded(vehicleName) do 
        Citizen.Wait(500)
    end
    local playerPed = PlayerPedId()
    local pos = GetEntityCoords(playerPed)
    if IsPedInAnyVehicle(playerPed, true) then
        Deletevehicle()
    end
    local vehicle = CreateVehicle(vehicleName, pos.x, pos.y, pos.z, GetEntityHeading(playerPed), true, false)
    SetPedIntoVehicle(playerPed, vehicle, -1)
    SetEntityAsNoLongerNeeded(vehicle)
    SetModelAsNoLongerNeeded(vehicleName)
    notify("Bil spawnad.")
end

function DeleteVehicle()
    local playerPed = PlayerPedId()
    local vehicle = GetVehiclePedIsIn(playerPed, true)
    DeleteEntity(vehicle)
    notify("Bil raderad.")
end

function notify(text)
    SetNotificationTextEntry("STRING")
    AddTextComponentString(text)
    DrawNotification(true, false)
end